def count_in_list(lst: list, elem) -> int:
    return lst.count(elem)
