from setuptools import setup

setup(
   name='ft_package',
   version='0.0.1',
   description='A sample test package',
   author='thole',
   author_email='thole@student.42.fr',
   url='https://github.com/FrenchDandelions/ft_package',
)
