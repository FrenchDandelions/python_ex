This is a basic package for my python piscine
