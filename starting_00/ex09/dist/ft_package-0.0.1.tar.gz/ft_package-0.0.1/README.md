This is a basic package for my python piscine
Please run the run.sh before installing the package