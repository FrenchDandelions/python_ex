def count_in_list(lst: list, elem) -> int:
    """count_in_list(lst: list, elem) --> count of
    elem in lst"""
    return lst.count(elem)
